<?php

namespace Drupal\d8training;

/**
 * Interface OpenWeatherForecasterInterface.
 *
 * @package Drupal\d8training
 */
interface OpenWeatherForecasterInterface {


}
