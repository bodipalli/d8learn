<?php

namespace Drupal\d8training;

/**
 * Interface DefaultServiceInterface.
 *
 * @package Drupal\d8training
 */
interface DefaultServiceInterface {


}
